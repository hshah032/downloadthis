from flask import Flask, redirect, url_for, render_template, request, jsonify,json

app = Flask(__name__)

post_data = [
    {
        'item_Num': '1',
        'part_Num': '3000380',
        'description': 'HMD RIGHT TEMPLE ASSEMBLY',
        'qty': '0'

    },
    {
        'item_Num': '2',
        'part_Num': '3000379',
        'description': 'HALO - LEFT TEMPLE ASSEMBLY',
        'qty': '0'
    },
    {
        'item_Num': '3',
        'part_Num': '4000748',
        'description': 'TEMPLE ARM OUTER COVER LEFT',
        'qty': '0'
    },
    {
        'item_Num': '4',
        'part_Num': '4000741',
        'description': 'HALO BLACK PERM BATTERY COVER',
        'qty': '0'
    }

];


# @app.route('/')
# def home():
#     return render_template('home.html')


@app.route('/', methods = ['GET', 'POST'])
def next_page():
    if request.method == 'GET':
        return render_template('next_page.html', posts=post_data)
    elif request.method == 'POST':
        #check which fields are changed and save those rows
        
        return jsonify(request.json)
        # return redirect(url_for('next_page'))






if __name__ == '__main__':
    app.run(port=3333, debug=True)
