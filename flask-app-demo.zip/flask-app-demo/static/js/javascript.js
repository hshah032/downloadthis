$(document).ready(function(){
    $('#ajax_data_load').click(function(){
        clicked = $(this).attr('name');
        $.ajax({
            url: 'http://127.0.0.1:3333/',
            dataSrc: 'data',
            type: 'POST',
            dataType: 'json',
            data: $('form').serialize(),
            success: function(data){
                console.log('Success Hit');
                console.log(data);
            
                },
            error: function(data){
                console.log('Error Hit');
                console.log(data);
                }
        });
    });
});

